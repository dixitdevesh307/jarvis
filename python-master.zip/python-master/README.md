# python project

create jarvis for windows using python

Installation
==============

step 1: open cmd and install requirement.txt
step 2: under your pass1.py file fill up your details like email id and password
step 3: under your jarvis.py file add your file path like your music dir path or any .exe file path
step 4: open cmd and type "python jarvis.py" to execute jarvis script

Feel free to ask doubts


project overview
=================
https://www.youtube.com/watch?v=HHkI5h1xnPw


complete project tutorial 
==========================
https://www.youtube.com/watch?v=59sLD4YDUHQ
