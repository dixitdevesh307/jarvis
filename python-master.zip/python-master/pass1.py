def getEmail():
	return "youremail@gmail.com"

def getPass():
	return "yourpassword"